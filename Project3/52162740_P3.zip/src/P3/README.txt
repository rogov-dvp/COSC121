Given:
	- the starter code here is the solution to P2

Required: 
	1) Exceptions and IO
	2) Testing