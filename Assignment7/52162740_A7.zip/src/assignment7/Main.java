package assignment7;

public class Main {
	public static void main(String[] args) {
		PatientManager pm = new PatientManager();
		pm.start();
		
		// used comparator
	}
}

