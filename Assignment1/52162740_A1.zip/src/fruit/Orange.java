package fruit;

public class Orange extends Fruit{

	public void makeOrangeJuice() {}
	public void saySomething() {System.out.println("I am an Orange");}
	
}
