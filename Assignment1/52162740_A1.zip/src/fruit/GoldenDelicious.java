package fruit;

public class GoldenDelicious extends Apple{

	public void saySomething() {System.out.println("I am a GoldenDelicious");}
	
}
