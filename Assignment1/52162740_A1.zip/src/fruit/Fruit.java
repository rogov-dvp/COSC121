package fruit;

public class Fruit {
	
	public void saySomething() {System.out.println("I am a Fruit");}
//	public void saySomething(String s) {System.out.println("Fruit says: " + s);}
		
	}

