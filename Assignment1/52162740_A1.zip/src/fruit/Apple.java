package fruit;

public class Apple extends Fruit{
	
	
	public void makeAppleCider() {}
	public void saySomething() {System.out.println("I am an Apple");}
	public void saySomething(String s) {System.out.println("Apple says: " + s);}
}
