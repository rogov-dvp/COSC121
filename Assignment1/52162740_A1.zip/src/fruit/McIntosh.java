package fruit;

public class McIntosh extends Apple{

	public void saySomething(String s) {System.out.println("McIntosh says: " + s);}
	
}
